

![LocalDeployment](../../repo_resources/Untitled%20design%20(1).jpg)




![ContainerDeployment](../../repo_resources/Untitled%20design%20(2).jpg)



![k8sDeployment](../../repo_resources/Untitled%20design%20(3).jpg)






