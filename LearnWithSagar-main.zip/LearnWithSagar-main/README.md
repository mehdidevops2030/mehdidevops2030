# LearnWithSagar
Everything DevOps, automation, SRE, Cloud


![LearnWithSagar](./repo_resources/learnwithsagar.png)

## Upcoming Free Bootcamps
1. [CKAD (Certified Kubernetes Application Developer)](./CKAD/)
2. [CKA (Certified Kubernetes Administrator)](./CKA/)
3. [CKS (Certified Kubernetes Specialist)](./CKS/)
4. [KCNA (Kubernetes and Cloud Native Associate)](./KCNA/)



## Want to know more about our Kubernetes Schlarship tracks ?

Head over to [our site](https://getfitwithsagar.prosperaweb.com/) to know more about the Scholarship track


## To participate in CKAD challgenge head over to [CKAD directory](./CKAD/)

