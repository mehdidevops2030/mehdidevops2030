# Now you have basic understanding of containers, lets deep dive

```
1. What is Docker container and images
2. Write a small application (any programming language)
    A. Steps to execute your code without Docker -
        i. Share code on Github
        ii. Add steps to run your applicaiton
    
    B. Steps to run your application in Docker container
        i. Upload code on Github 
        ii. Write a Dockerfile
        iii. Add readme.md file explaining steps to follow to run application in container

```

Note - 
```
1. Write blog in your own words and share link to blog
2. Share what you liked most about Docker and containers and how are you going to use it in projects.
```