
Let's start the Day0 of CKAD challenge.
Write a blog on below topics in your own words -

```
1. What are the containers and what problems we are trying to solve with the containers ?
2. How Virtual machines are different from Containers ?
3. What is Docker and explain Docker architecture ?
4. How Docker helps us for containerising application

```


Note - 
```
1. Write blog in your own words and share link to blog
2. Share what you liked most about Docker and containers and how are you going to use it in projects.
```
