Participant Name  | Blog Link
------------- | -------------
[Sagar Utekar](https://www.linkedin.com/in/sagar-utekar/)  | [Day0_solution]()
