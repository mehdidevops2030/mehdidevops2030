![ckadfree](../repo_resources/POD.gif)


# what is CKAD ?
```
Certified Kubernetes Application Developer exam is 

Online Exam Delivery
Duration of Exam 2 hours
Certification Valid 3 Years
12 Month Exam Eligibility
One Retake
PDF Certificate and Digital Badge
Software Version: Kubernetes v1.27
Performance-Based Exam
Exam Simulator
```


# Register for free [CKAD course](https://getfitwithsagar.graphy.com/courses/Free-CKAD-Series-64803ac6e4b00d372ab6a817)


# Links to session videos
1. [Day 1 : Ask me Anything](https://getfitwithsagar.graphy.com/s/courses/64803ac6e4b00d372ab6a817/take)
2. [Day 2 : Container Fundamentls](https://getfitwithsagar.graphy.com/s/courses/64803ac6e4b00d372ab6a817/take)
3. [Day 3 : Kubernetes Fundamentals](https://getfitwithsagar.graphy.com/s/courses/64803ac6e4b00d372ab6a817/take)



# How to submit solutions for CKAD assignments
1. Clone this repository
2. Check out the [Assignments directory](./Assignments/) for day wise questions
3. Solve the assignment question.
4. Write a blog about your learning and submit Github code link wherver required.
5. Use proper hashtags in blog and social media posts and don't forget to tag us in your posts : 
    #getfitwithsagar
    #learnwithsagar
    #ckadwithsagar
    #ckadchallenge
6. Add your name and link to blog in submission_tracker.md file in day wise directory.



# Bonus tips
- Write blogs in your own words, do not copy the content from internet or someone else content as we'll be doing plagarism checks.
- Earlier you submit the blog and complete all activities is better.



# Need help
Join our active community on whatsapp and reach out to moderators to get help.

Thank you, can't wait to see all of you taking part in CKAD series and assignment activities
